package com.example.marketplant_mobil;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.marketplant_mobil.modelos.ProductoRequest;
import com.example.marketplant_mobil.retrofit.ApiClient;
import com.google.android.material.textfield.TextInputEditText;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Publicar_producto extends AppCompatActivity {

    EditText id_nombre,id_decripcion,id_precio;
    Button btnuno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publicar_producto);

        id_nombre=findViewById(R.id.id_nombre);
        id_decripcion=findViewById(R.id.id_decripcion);
        id_precio=findViewById(R.id.id_precio);

        btnuno=findViewById(R.id.button12);

        btnuno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (TextUtils.isEmpty(id_nombre.getText().toString()) || TextUtils.isEmpty(id_decripcion.getText().toString()) || TextUtils.isEmpty(id_precio.getText().toString())) {

                    String message = "todos los campos requeridos";
                    Toast.makeText(Publicar_producto.this, message, Toast.LENGTH_SHORT).show();

                } else {
                    ProductoRequest produtoRequest = new ProductoRequest();
                    produtoRequest.setNombre(id_nombre.getText().toString());
                    produtoRequest.setDescripcion(id_decripcion.getText().toString());
                   produtoRequest.setPrecio(id_precio.getText().toString());

                    producto(produtoRequest);
                }

            }
        });
    }

    private void producto(ProductoRequest produtoRequest) {
        Call<PoductoResponse> poductoResponseCall= ApiClient.getService().producto(produtoRequest);
        poductoResponseCall.enqueue(new Callback<PoductoResponse>() {
            @Override
            public void onResponse(Call<PoductoResponse> call, Response<PoductoResponse> response) {

                if (response.isSuccessful()) {

                    String message = "successfull";
                    Toast.makeText(Publicar_producto.this, message, Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(Publicar_producto.this, MainActivity.class));
                    finish();

                } else {

                    String message = "ocurrio un error intenta de nuevo";
                    Toast.makeText(Publicar_producto.this, message, Toast.LENGTH_SHORT).show();

                }

            }

            @Override
            public void onFailure(Call<PoductoResponse> call, Throwable t) {

                String message = t.getLocalizedMessage();
                Toast.makeText(Publicar_producto.this, message, Toast.LENGTH_SHORT).show();

            }
        });

    }
}